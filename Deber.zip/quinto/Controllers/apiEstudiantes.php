<?php

/*
include_once "../Models/borrar.php";
include_once "../Models/consulta.php";
include_once "../Models/guardar.php";
include_once "../Models/actualizar.php";
$opc = $_SERVER['REQUEST_METHOD'];

$cedula = $_GET["cedula"] ?? null;
switch($opc){
    case "GET":
        crudS::SeleccionarEstudiantes($cedula);
        break;
    case "POST":
        crudG::GuardarEstudiantes();
        break;
    case "PUT":
         crudA::ActualizarEstudiantes();
            break;
    case "DELETE":
        $cedula=$_GET['cedula'];
        crudB::BorrarEstudiantes($cedula);
        break;
}
*/
include_once '../Models/consulta.php';
include_once '../Models/borrar.php';
include_once '../Models/guardar.php';
include_once '../Models/actualizar.php';

header('Content-Type: application/json');

$opc= $_SERVER['REQUEST_METHOD'];
switch($opc){
    case 'GET':
        //Se puede acceder a un metodo estatico con '::'
        //$cedula = $_GET['ced_est'];
        //CrudS::seleccionarEstudiantes($cedula);
        CrudS::seleccionarEstudiantes();
        break;
    case 'POST':
        $datoG = json_decode(file_get_contents('php://input'));
            crudG::guardarEstudiante($datoG -> cedula,$datoG -> nombre,$datoG -> apellido,$datoG -> direccion,$datoG -> telefono);
        break;
    case 'DELETE':
        $cedula =$_GET['cedula'];
        CrudB::BorrarEstudiantes($cedula);
        break;
    case 'PUT':
        // $data = json_decode(file_get_contents("php://input"), true);
        // $ced = $data['cedula'];
        // $nom = $data['nombre'];
        // $ape = $data['apellido'];
        // $dir = $data['direccion'];
        // $tel = $data['telefono'];
        // CrudA::ActualizarEstudiantes($ced, $nom, $ape, $dir, $tel);
        // break;

        $datoMod = json_decode(file_get_contents('php://input'));
            //print_r($dato);
            crudA::ActualizarEstudiantes($datoMod -> cedula,$datoMod -> nombre,$datoMod -> apellido,$datoMod -> direccion,
            $datoMod -> telefono);
            break;
    }
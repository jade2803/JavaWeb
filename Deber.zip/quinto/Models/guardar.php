<?php
class crudG
{


    //GRUPO DOS
    // public static function GuardarEstudiantes()
    // {
    //     include_once('conexion.php');
    //     header('Content-Type: application/json');
    //     $data = json_decode(file_get_contents('php://input'), true);
    //     $cedula = $data['cedula'];
    //     $nombre = $data['nombre'];
    //     $apellido = $data["apellido"];
    //     $direccion = $data["direccion"];
    //     $telefono = $data["telefono"];
    //     $objeto = new conexion();
    //     $conectar = $objeto->conectar();
    //     $insertSql = "INSERT INTO estudiantes (cedula, nombre, apellido, direccion, telefono) VALUES ('$cedula','$nombre','$apellido','$direccion','$telefono')";
    //     $resultado = $conectar->prepare($insertSql);
    //     $resultado->execute();
    //     echo json_encode($resultado);
    //     $conectar->commit();
    // }


    //GRUPO TRES
    public static function guardarEstudiante($ced_est, $nom_est, $ape_est, $dir_est, $tel_est)
    {
        include_once('conexion.php');
        $object = new conexion();
        $conectar = $object->conectar();
        $insert = "insert into estudiante values('$ced_est','$nom_est','$ape_est', '$dir_est', '$tel_est')";
        $result = $conectar->prepare($insert);
        $result->execute();
        $dataJs = json_encode($result);
        print_r($dataJs);
        //echo json_encode($result);
        $conectar->commit();
    }
}

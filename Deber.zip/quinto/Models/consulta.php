<?php
class crudS
{



    /*
    public static function SeleccionarEstudiantes($cedula){
        include_once('conexion.php');
        header('Content-Type: application/json');
        $objeto = new conexion();
        $conexion = $objeto->conectar();
        $sqlSelect = "Select * FROM estudiantes WHERE cedula LIKE '$cedula%'";
        $resultado = $conexion->prepare($sqlSelect);
        $resultado->execute();
        $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
        $dataJs = json_encode($data);
        print_r($dataJs);
    }
*/

    //GRUPO DOS
    // public static function SeleccionarEstudiantes(){
    //     include_once('conexion.php');
    //     header('Content-Type: application/json');
    //     $objeto = new conexion();
    //     $conexion = $objeto->conectar();
    //     $sqlSelect = "Select * from estudiantes";
    //     $resultado = $conexion->prepare($sqlSelect);
    //     $resultado->execute();
    //     $data=$resultado->fetchAll(PDO::FETCH_ASSOC);
    //     $dataJs = json_encode($data);
    //     print_r($dataJs);
    // }


    //GRUPO TRES
    public static function seleccionarEstudiantes()
    {
        include_once('conexion.php');
        $object = new conexion();
        $conn = $object->conectar();
        $sqlSelect = "select * from estudiante";
        $result = $conn->prepare($sqlSelect);
        $result->execute();
        $data = $result->fetchAll(PDO::FETCH_ASSOC);
        $dataJs = json_encode($data);
        print_r($dataJs);
    }
}

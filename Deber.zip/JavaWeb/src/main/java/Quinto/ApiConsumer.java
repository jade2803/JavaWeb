/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Quinto;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpResponse.BodyHandlers;
import org.json.JSONArray;
import org.json.JSONObject;

public class ApiConsumer {

    private final HttpClient httpClient;
    private static String URL = "http://localhost/quinto/controllers/apiEstudiantes.php";

    public ApiConsumer() {
        this.httpClient = HttpClient.newHttpClient();
    }

    public JSONArray getEstudiantes() throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(URL))
                .GET()
                .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        return new JSONArray(response.body());
    }

    public HttpResponse<String> postEstudiante(String... student) {
        JSONObject estudiante = new JSONObject();
        estudiante.put("cedula", student[0]);
        estudiante.put("nombre", student[1]);
        estudiante.put("apellido", student[2]);
        estudiante.put("direccion", student[3]);
        estudiante.put("telefono", student[4]);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(URL))
                .header("Accept", "*/*")
                .POST(HttpRequest.BodyPublishers.ofString(estudiante.toString()))
                .build();
        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            return response;
        } catch (InterruptedException e) {
            System.out.println("Error al enviar");
            return null;
        } catch (IOException a) {
            System.out.println("Error al enviar.");
            return null;

        }
    }

    public HttpResponse<String> deleteEstudiante(String cedula) {
        HttpResponse<String> response = null;
        URI uri = URI.create(URL + "?cedula=" + cedula);
        HttpRequest request = HttpRequest.newBuilder()
                .uri(uri)
                .DELETE()
                .build();
        try {
            response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            return response;
        } catch (InterruptedException e) {
            System.out.println("Error al eliminar");
            return response;
        } catch (IOException a) {
            System.out.println("Error al eliminar.");
            return response;

        }
    }

    public int getResponseStatusCode(HttpResponse<String> response) {
        return response.statusCode();
    }

    public HttpResponse<String> putEstudiante(String... algo) {
        HttpResponse<String> response = null;
        URI uri = URI.create(URL + "?cedula=" + algo[0] + "&nombre=" + algo[1] + "&apellido=" + algo[2] + "&direccion=" + algo[3]
                + "&telefono=" + algo[4]);
        HttpRequest request = HttpRequest.newBuilder()
                .uri(uri)
                .PUT(HttpRequest.BodyPublishers.noBody())
                .build();
        try {
            response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            return response;
        } catch (InterruptedException e) {
            System.out.println("Error al editar");
            return response;
        } catch (IOException a) {
            System.out.println("Error al editar.");
            return response;

        }
    }
    
    
    public HttpResponse<String> updateUser(String cedula, String nombre, String apellido, String direccion, String telefono) throws Exception {
        // Crea el objeto JSON con los datos a actualizar
        JSONObject data = new JSONObject();
        data.put("cedula", cedula);
        data.put("nombre", nombre);
        data.put("apellido", apellido);
        data.put("direccion", direccion);
        data.put("telefono", telefono);

        // Construye la URI
        URI uri = URI.create(URL);

        // Crea una solicitud PUT para actualizar el usuario
        HttpRequest request = HttpRequest.newBuilder()
                .uri(uri)
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(data.toString()))
                .build();

        // Envía la solicitud y devuelve la respuesta
        return httpClient.send(request, BodyHandlers.ofString());
    }

}
